# Hey There Ultimate

Chat & Chamadas PWA completo.

## Como rodar localmente

```bash
git clone https://github.com/SEU_USUARIO/hey-there-ultimate.git
cd hey-there-ultimate
npm install
npm start
```

Acede a: http://localhost:5000

Funciona offline via PWA.